var mongoose = require('mongoose');
var schema = mongoose.Schema;

var userSchema = new schema ({
    name : {type : String, required: true, max: 50},
    password: { type : String, required: true, max: 50},
    email: { type : String, required: true, max: 50},
    address: { type : String, required: true, max: 50}
})

// Export the model
module.exports = mongoose.model('user', userSchema);


