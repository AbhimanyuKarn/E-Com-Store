var User = require('../model/user');

exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

// GET method
exports.user_detailsAll = function (req, res) {
    //var user = new User(req.body);
    User.find({}, function (err, users) {
        if (err) return next(err);
        res.send(users);
    })
};


//Get method by id
exports.user_details = function (req, res) {
    user.findById(req.params.id, function (err, user) {
        if (err) return next(err);
        res.send(user);
    })
};


//Delete method
exports.user_detailsDelete = function (req, res) {
    user.findByIdAndRemove(req.params.id, function (err, user) {
        if (err) return next(err);
        res.send(user.name + " has been deleted succesfully");
    })
};

//Update  method
exports.user_detailsUpdate = function (req, res) {
    user.findByIdAndUpdate(req.params.id, function (err, user) {
        if (err) return next(err);
        res.send(user.name + " has been updated succesfully");
    })
};


//post method

exports.user_create = function (req, res) {
    var user = new User(req.body);
    user.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send(user)
    })
};


