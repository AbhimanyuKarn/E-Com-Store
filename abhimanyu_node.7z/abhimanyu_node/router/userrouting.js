var express = require('express');
var router = express.Router();
var fb_controller = require('../controller/usercontroller');

router.get('/', fb_controller.user_detailsAll);

router.post('/create', fb_controller.user_create);

router.get('/:id', fb_controller.user_details);

router.put('/:id/update', fb_controller.user_detailsUpdate);

router.delete('/:id/delete', fb_controller.user_detailsDelete);


module.exports = router;